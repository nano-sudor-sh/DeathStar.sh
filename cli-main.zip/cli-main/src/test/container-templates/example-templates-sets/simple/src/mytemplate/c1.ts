export class C1 {
	constructor() {
		// Add your code here
	}

	// Add your methods here
}