export class A1 {
	constructor() {
		// Add your code here
	}

	// Add your methods here
}