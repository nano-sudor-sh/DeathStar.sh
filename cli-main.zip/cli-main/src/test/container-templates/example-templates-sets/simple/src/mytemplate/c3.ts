export class C3 {
	constructor() {
		// Add your code here
	}

	// Add your methods here
}