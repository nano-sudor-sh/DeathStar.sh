#!/bin/sh
set -e

echo "Activating feature 'b'"

touch /usr/local/bin/b

