#!/bin/sh

echo "I AM A DIFFERENT SCRIPT"