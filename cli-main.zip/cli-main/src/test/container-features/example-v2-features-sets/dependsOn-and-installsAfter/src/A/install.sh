#!/bin/sh

NAME="A"
echo "Installing ${NAME}"