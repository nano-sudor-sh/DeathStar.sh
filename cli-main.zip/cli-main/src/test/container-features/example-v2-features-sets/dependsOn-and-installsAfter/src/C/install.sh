#!/bin/sh

NAME="C"
echo "Installing ${NAME}"