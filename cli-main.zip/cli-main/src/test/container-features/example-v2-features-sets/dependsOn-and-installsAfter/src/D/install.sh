#!/bin/sh

NAME="D"
echo "Installing ${NAME}"