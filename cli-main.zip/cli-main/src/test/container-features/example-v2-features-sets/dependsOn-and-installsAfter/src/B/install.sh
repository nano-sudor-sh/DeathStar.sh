#!/bin/sh

NAME="B"
echo "Installing ${NAME}"