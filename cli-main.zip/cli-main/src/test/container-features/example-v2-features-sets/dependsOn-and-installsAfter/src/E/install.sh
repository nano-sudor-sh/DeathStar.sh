#!/bin/sh

NAME="E"
echo "Installing ${NAME}"