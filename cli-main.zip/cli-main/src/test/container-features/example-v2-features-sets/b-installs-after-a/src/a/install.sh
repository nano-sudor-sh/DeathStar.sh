#!/bin/sh
set -e

echo "Activating feature 'a'"

touch /usr/local/bin/a

