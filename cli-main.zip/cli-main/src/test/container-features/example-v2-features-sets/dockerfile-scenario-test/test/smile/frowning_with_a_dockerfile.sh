#!/bin/bash

set -e

./frowning.sh